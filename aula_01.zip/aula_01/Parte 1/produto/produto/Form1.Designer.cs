﻿using System;
using System.Windows.Forms;
using System.Drawing;
using produto;

namespace produto
{
    public partial class Form1 : Form
    {
        private Produto produto;

        public Form1()
        {
            InitializeComponent();
            produto = new Produto();
        }

        private void InitializeComponent()
        {
            this.Text = "Cadastro de Produto";
            this.Size = new System.Drawing.Size(400, 300);

            Font fonte = new Font("Arial", 12);

            Label lblCodigo = new Label();
            lblCodigo.Text = "Código:";
            lblCodigo.Location = new System.Drawing.Point(20, 20);
            lblCodigo.Size = new System.Drawing.Size(100, 30);
            lblCodigo.Font = fonte;

            TextBox txtCodigo = new TextBox();
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Location = new System.Drawing.Point(120, 20);
            txtCodigo.Size = new System.Drawing.Size(200, 30);
            txtCodigo.Font = fonte;

            Label lblDescricao = new Label();
            lblDescricao.Text = "Descrição:";
            lblDescricao.Location = new System.Drawing.Point(20, 60);
            lblDescricao.Size = new System.Drawing.Size(100, 30);
            lblDescricao.Font = fonte;

            TextBox txtDescricao = new TextBox();
            txtDescricao.Name = "txtDescricao";
            txtDescricao.Location = new System.Drawing.Point(120, 60);
            txtDescricao.Size = new System.Drawing.Size(200, 30);
            txtDescricao.Font = fonte;

            Label lblQuantidade = new Label();
            lblQuantidade.Text = "Quantidade:";
            lblQuantidade.Location = new System.Drawing.Point(20, 100);
            lblQuantidade.Size = new System.Drawing.Size(100, 30);
            lblQuantidade.Font = fonte;

            TextBox txtQuantidade = new TextBox();
            txtQuantidade.Name = "txtQuantidade";
            txtQuantidade.Location = new System.Drawing.Point(120, 100);
            txtQuantidade.Size = new System.Drawing.Size(200, 30);
            txtQuantidade.Font = fonte;

            Label lblValor = new Label();
            lblValor.Text = "Valor:";
            lblValor.Location = new System.Drawing.Point(20, 140);
            lblValor.Size = new System.Drawing.Size(100, 30);
            lblValor.Font = fonte;

            TextBox txtValor = new TextBox();
            txtValor.Name = "txtValor";
            txtValor.Location = new System.Drawing.Point(120, 140);
            txtValor.Size = new System.Drawing.Size(200, 30);
            txtValor.Font = fonte;

            Button btnSalvar = new Button();
            btnSalvar.Text = "Salvar";
            btnSalvar.Location = new System.Drawing.Point(120, 180);
            btnSalvar.Size = new System.Drawing.Size(100, 40);
            btnSalvar.Font = fonte;
            btnSalvar.Click += (s, e) =>
            {
                try
                {
                    produto.SetCodigoProduto(int.Parse(txtCodigo.Text));
                    produto.SetDescricao(txtDescricao.Text);
                    produto.SetQuantidadeEstoque(int.Parse(txtQuantidade.Text));
                    produto.SetValorUnitario(decimal.Parse(txtValor.Text));

                    ShowCustomMessageBox($"Produto salvo:\n" +
                        $"Código: {produto.GetCodigoProduto()}\n" +
                        $"Descrição: {produto.GetDescricao()}\n" +
                        $"Quantidade: {produto.GetQuantidadeEstoque()}\n" +
                        $"Valor: {produto.GetValorUnitario():C}", "Informação", fonte);
                }
                catch (Exception ex)
                {
                    ShowCustomMessageBox($"Erro: {ex.Message}", "Erro", fonte);
                }
            };

            Button btnExibir = new Button();
            btnExibir.Text = "Exibir";
            btnExibir.Location = new System.Drawing.Point(230, 180);
            btnExibir.Size = new System.Drawing.Size(100, 40);
            btnExibir.Font = fonte;
            btnExibir.Click += (s, e) =>
            {
                ShowCustomMessageBox($"Dados do Produto:\n" +
                    $"Código: {produto.GetCodigoProduto()}\n" +
                    $"Descrição: {produto.GetDescricao()}\n" +
                    $"Quantidade: {produto.GetQuantidadeEstoque()}\n" +
                    $"Valor: {produto.GetValorUnitario():C}", "Informação", fonte);
            };

            this.Controls.AddRange(new Control[] { lblCodigo, txtCodigo, lblDescricao, txtDescricao,
                lblQuantidade, txtQuantidade, lblValor, txtValor, btnSalvar, btnExibir });
        }

        private void ShowCustomMessageBox(string message, string title, Font font)
        {
            Form messageBox = new Form();
            messageBox.Text = title;
            messageBox.Size = new System.Drawing.Size(400, 250);
            messageBox.StartPosition = FormStartPosition.CenterParent;
            messageBox.FormBorderStyle = FormBorderStyle.FixedDialog;
            messageBox.MaximizeBox = false;
            messageBox.MinimizeBox = false;

            Label lblMessage = new Label();
            lblMessage.Text = message;
            lblMessage.Location = new System.Drawing.Point(20, 20);
            lblMessage.Size = new System.Drawing.Size(340, 100);
            lblMessage.Font = font;
            lblMessage.AutoSize = false;

            Button btnOk = new Button();
            btnOk.Text = "OK";
            btnOk.Location = new System.Drawing.Point(150, 130);
            btnOk.Size = new System.Drawing.Size(100, 40);
            btnOk.Font = font;
            btnOk.Click += (s, e) => messageBox.Close();

            messageBox.Controls.AddRange(new Control[] { lblMessage, btnOk });
            messageBox.ShowDialog();
        }
    }
}