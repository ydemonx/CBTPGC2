﻿using System;

namespace produto
{
    public class Produto
    {
        private int codigoProduto;
        private string descricao;
        private int quantidadeEstoque;
        private decimal valorUnitario;

        
        public Produto()
        {
        }

        public Produto(int codigo, string desc, int quantidade, decimal valor)
        {
            codigoProduto = codigo;
            descricao = desc;
            quantidadeEstoque = quantidade;
            valorUnitario = valor;
        }

        public int GetCodigoProduto()
        {
            return codigoProduto;
        }

        public void SetCodigoProduto(int codigo)
        {
            if (codigo <= 0)
                throw new ArgumentException("Código do produto deve ser maior que zero.");
            codigoProduto = codigo;
        }

        public string GetDescricao()
        {
            return descricao;
        }

        public void SetDescricao(string desc)
        {
            if (string.IsNullOrWhiteSpace(desc))
                throw new ArgumentException("Descrição não pode ser vazia.");
            descricao = desc;
        }

        public int GetQuantidadeEstoque()
        {
            return quantidadeEstoque;
        }

        public void SetQuantidadeEstoque(int quantidade)
        {
            if (quantidade < 0)
                throw new ArgumentException("Quantidade em estoque não pode ser negativa.");
            quantidadeEstoque = quantidade;
        }

        public decimal GetValorUnitario()
        {
            return valorUnitario;
        }

        public void SetValorUnitario(decimal valor)
        {
            if (valor < 0)
                throw new ArgumentException("Valor unitário não pode ser negativo.");
            valorUnitario = valor;
        }
    }
}