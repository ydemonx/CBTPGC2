﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using retangulo;

namespace retangulo
{
    public partial class FormRetangulo : Form
    {
        private List<Retangulo> retangulos;

        public FormRetangulo()
        {
            InitializeComponent();
            retangulos = new List<Retangulo>();
        }

        private void InitializeComponent()
        {
            this.Text = "Cadastro de Retângulo";
            this.Size = new System.Drawing.Size(400, 225); 

            Font fonte = new Font("Arial", 12);

            Label lblCodigo = new Label();
            lblCodigo.Text = "Código:";
            lblCodigo.Location = new System.Drawing.Point(20, 20);
            lblCodigo.Size = new System.Drawing.Size(100, 30);
            lblCodigo.Font = fonte;

            TextBox txtCodigo = new TextBox();
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Location = new System.Drawing.Point(120, 20);
            txtCodigo.Size = new System.Drawing.Size(200, 30);
            txtCodigo.Font = fonte;

            Label lblBase = new Label();
            lblBase.Text = "Base:";
            lblBase.Location = new System.Drawing.Point(20, 60);
            lblBase.Size = new System.Drawing.Size(100, 30);
            lblBase.Font = fonte;

            TextBox txtBase = new TextBox();
            txtBase.Name = "txtBase";
            txtBase.Location = new System.Drawing.Point(120, 60);
            txtBase.Size = new System.Drawing.Size(200, 30);
            txtBase.Font = fonte;

            Label lblAltura = new Label();
            lblAltura.Text = "Altura:";
            lblAltura.Location = new System.Drawing.Point(20, 100);
            lblAltura.Size = new System.Drawing.Size(100, 30);
            lblAltura.Font = fonte;

            TextBox txtAltura = new TextBox();
            txtAltura.Name = "txtAltura";
            txtAltura.Location = new System.Drawing.Point(120, 100);
            txtAltura.Size = new System.Drawing.Size(200, 30);
            txtAltura.Font = fonte;

            Button btnSalvar = new Button();
            btnSalvar.Text = "Salvar";
            btnSalvar.Location = new System.Drawing.Point(120, 140);
            btnSalvar.Size = new System.Drawing.Size(100, 40);
            btnSalvar.Font = fonte;
            btnSalvar.Click += (s, e) =>
            {
                try
                {
                    int codigo = int.Parse(txtCodigo.Text);
                    double baseRet = double.Parse(txtBase.Text);
                    double altura = double.Parse(txtAltura.Text);

                    Retangulo existente = retangulos.Find(r => r.GetCodigo() == codigo);
                    if (existente != null)
                    {
                        existente.SetBase(baseRet);
                        existente.SetAltura(altura);
                        ShowCustomMessageBox($"Retângulo com código {codigo} atualizado:\n" +
                            $"Base: {existente.GetBase():F2}\n" +
                            $"Altura: {existente.GetAltura():F2}", "Informação", fonte);
                    }
                    else
                    {
                        Retangulo novo = new Retangulo();
                        novo.SetCodigo(codigo);
                        novo.SetBase(baseRet);
                        novo.SetAltura(altura);
                        retangulos.Add(novo);
                        ShowCustomMessageBox($"Retângulo com código {codigo} salvo:\n" +
                            $"Base: {novo.GetBase():F2}\n" +
                            $"Altura: {novo.GetAltura():F2}", "Informação", fonte);
                    }
                }
                catch (Exception ex)
                {
                    ShowCustomMessageBox($"Erro: {ex.Message}", "Erro", fonte);
                }
            };

            Button btnExibir = new Button();
            btnExibir.Text = "Exibir";
            btnExibir.Location = new System.Drawing.Point(230, 140);
            btnExibir.Size = new System.Drawing.Size(100, 40);
            btnExibir.Font = fonte;
            btnExibir.Click += (s, e) =>
            {
                try
                {
                    int codigo = int.Parse(txtCodigo.Text);
                    Retangulo retangulo = retangulos.Find(r => r.GetCodigo() == codigo);
                    if (retangulo != null)
                    {
                        ShowCustomMessageBox($"Dados do Retângulo (Código: {codigo}):\n" +
                            $"Base: {retangulo.GetBase():F2}\n" +
                            $"Altura: {retangulo.GetAltura():F2}\n" +
                            $"{retangulo.CalculaArea()}\n" +
                            $"{retangulo.CalculaPerimetro()}", "Informação", fonte);
                    }
                    else
                    {
                        ShowCustomMessageBox($"Nenhum retângulo encontrado com o código {codigo}.", "Erro", fonte);
                    }
                }
                catch (Exception ex)
                {
                    ShowCustomMessageBox($"Erro: {ex.Message}", "Erro", fonte);
                }
            };

            this.Controls.AddRange(new Control[] { lblCodigo, txtCodigo, lblBase, txtBase, lblAltura, txtAltura, btnSalvar, btnExibir });
        }

        private void ShowCustomMessageBox(string message, string title, Font font)
        {
            Form messageBox = new Form();
            messageBox.Text = title;
            messageBox.Size = new System.Drawing.Size(400, 225);
            messageBox.StartPosition = FormStartPosition.CenterParent;
            messageBox.FormBorderStyle = FormBorderStyle.FixedDialog;
            messageBox.MaximizeBox = false;
            messageBox.MinimizeBox = false;

            Label lblMessage = new Label();
            lblMessage.Text = message;
            lblMessage.Location = new System.Drawing.Point(20, 20);
            lblMessage.Size = new System.Drawing.Size(340, 100);
            lblMessage.Font = font;
            lblMessage.AutoSize = false;

            Button btnOk = new Button();
            btnOk.Text = "OK";
            btnOk.Location = new System.Drawing.Point(150, 130);
            btnOk.Size = new System.Drawing.Size(100, 40);
            btnOk.Font = font;
            btnOk.Click += (s, e) => messageBox.Close();

            messageBox.Controls.AddRange(new Control[] { lblMessage, btnOk });
            messageBox.ShowDialog();
        }
    }
}