﻿using System;

namespace retangulo
{
    public class Retangulo
    {
        private int codigo;
        private double baseRetangulo;
        private double altura;

        public Retangulo()
        {
        }

        public Retangulo(int cod, double baseRet, double alt)
        {
            codigo = cod;
            baseRetangulo = baseRet;
            altura = alt;
        }

        public int GetCodigo()
        {
            return codigo;
        }

        public void SetCodigo(int cod)
        {
            if (cod <= 0)
                throw new ArgumentException("O código deve ser maior que zero.");
            codigo = cod;
        }

        public double GetBase()
        {
            return baseRetangulo;
        }

        public void SetBase(double baseRet)
        {
            if (baseRet <= 0)
                throw new ArgumentException("A base deve ser maior que zero.");
            baseRetangulo = baseRet;
        }

        public double GetAltura()
        {
            return altura;
        }

        public void SetAltura(double alt)
        {
            if (alt <= 0)
                throw new ArgumentException("A altura deve ser maior que zero.");
            altura = alt;
        }

        public string CalculaArea()
        {
            double area = baseRetangulo * altura;
            return $"Área: {area:F2}";
        }

        public string CalculaPerimetro()
        {
            double perimetro = 2 * (baseRetangulo + altura);
            return $"Perímetro: {perimetro:F2}";
        }
    }
}