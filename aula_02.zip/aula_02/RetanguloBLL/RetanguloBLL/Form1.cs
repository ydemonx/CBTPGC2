﻿using System;
using System.Windows.Forms;
using RetanguloBLL;

namespace RetanguloBLL
{
    public partial class Form1 : Form
    {
        private readonly RetanguloBLL _retanguloBLL;

        public Form1()
        {
            InitializeComponent();
            _retanguloBLL = new RetanguloBLL();
        }


        private bool TentarObterRetanguloValido(out Retangulo retangulo)
        {
            retangulo = new Retangulo();

            if (!float.TryParse(txtBase.Text, out float baseValor))
            {
                MessageBox.Show("O valor da 'Base' não é um número válido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!float.TryParse(txtAltura.Text, out float alturaValor))
            {
                MessageBox.Show("O valor da 'Altura' não é um número válido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            retangulo.Base = baseValor;
            retangulo.Altura = alturaValor;

            string erros = _retanguloBLL.ValidarRetangulo(retangulo);

            if (!string.IsNullOrEmpty(erros))
            {
                MessageBox.Show(erros, "Erros de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btnValidar_Click_1(object sender, EventArgs e)
        {
            if (TentarObterRetanguloValido(out _))
            {
                MessageBox.Show("Os dados são válidos!",
                                "Sucesso",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private void btnCalcularArea_Click_1(object sender, EventArgs e)
        {
            if (TentarObterRetanguloValido(out Retangulo retangulo))
            {
                float area = retangulo.Base * retangulo.Altura;
                MessageBox.Show($"A área é: {area}",
                                "Resultado",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }
    }
}
