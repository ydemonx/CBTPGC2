﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetanguloBLL
{
    public class Retangulo
    {
        public float Base { get; set; }
        public float Altura { get; set; }
    }
}
