﻿using System.Text;

namespace RetanguloBLL
{
    public class RetanguloBLL
    {
        public string ValidarRetangulo(Retangulo retangulo)
        {
            var erros = new StringBuilder();

            if (retangulo.Base <= 0)
            {
                erros.AppendLine("O campo 'Base' é obrigatório e deve ser um número positivo.");
            }

            if (retangulo.Altura <= 0)
            {
                erros.AppendLine("O campo 'Altura' é obrigatório e deve ser um número positivo.");
            }

            return erros.ToString();
        }
    }
}