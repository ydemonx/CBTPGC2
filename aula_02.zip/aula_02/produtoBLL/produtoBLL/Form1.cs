﻿using System;
using System.Text;
using System.Windows.Forms;
using produtoBLL;

namespace ValidacaoProdutoWinForms
{
    public partial class Form1 : Form
    {
        private readonly ProdutoBLL _produtoBLL;

        public Form1()
        {
            InitializeComponent();
            _produtoBLL = new ProdutoBLL();
        }

        private void btnValidar_Click_1(object sender, EventArgs e)
        {
            int.TryParse(txtCodigo.Text, out int codigo);

            int.TryParse(txtQuantidade.Text, out int quantidade);

            decimal.TryParse(txtValorUnitario.Text, out decimal valorUnitario);

            var produto = new Produto
            {
                CodigoProduto = codigo,
                NomeProduto = txtNome.Text,
                QuantidadeEstoque = quantidade,
                ValorUnitario = valorUnitario
            };

            string erros = _produtoBLL.ValidarProduto(produto);

            if (string.IsNullOrEmpty(erros))
            {
                MessageBox.Show("Produto validado com sucesso!",
                                "Sucesso",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(erros,
                                "Erros de Validação Encontrados",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }
    }
}

