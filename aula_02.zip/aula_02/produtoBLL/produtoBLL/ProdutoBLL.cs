﻿using System.Text;
using produtoBLL;

public class ProdutoBLL
{
    public string ValidarProduto(Produto produto)
    {
        StringBuilder erros = new StringBuilder();

        if (produto.CodigoProduto <= 0)
        {
            erros.AppendLine("O código do produto é obrigatório e deve ser um número inteiro positivo.");
        }

        if (string.IsNullOrWhiteSpace(produto.NomeProduto))
        {
            erros.AppendLine("O nome do produto é obrigatório.");
        }

        if (produto.QuantidadeEstoque <= 0)
        {
            erros.AppendLine("A quantidade em estoque é obrigatória e deve ser um número inteiro positivo.");
        }

        if (produto.ValorUnitario <= 0)
        {
            erros.AppendLine("O valor unitário é obrigatório e deve ser um número positivo.");
        }

        return erros.ToString();
    }
}
