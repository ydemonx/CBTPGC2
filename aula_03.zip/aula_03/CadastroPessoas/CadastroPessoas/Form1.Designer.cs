﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Policy;

namespace CadastroPessoas
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labelCodigo = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.labelSexo = new System.Windows.Forms.Label();
            this.labelIdade = new System.Windows.Forms.Label();
            this.textBoxCodigo = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.comboBoxSexo = new System.Windows.Forms.ComboBox();
            this.maskedTextBoxIdade = new System.Windows.Forms.MaskedTextBox();
            this.buttonCadastrar = new System.Windows.Forms.Button();
            this.labelConsultaCodigo = new System.Windows.Forms.Label();
            this.textBoxConsultaCodigo = new System.Windows.Forms.TextBox();
            this.buttonConsultar = new System.Windows.Forms.Button();
            this.labelConsultaNome = new System.Windows.Forms.Label();
            this.labelConsultaSexo = new System.Windows.Forms.Label();
            this.labelConsultaIdade = new System.Windows.Forms.Label();
            this.textBoxConsultaNome = new System.Windows.Forms.TextBox();
            this.textBoxConsultaSexo = new System.Windows.Forms.TextBox();
            this.textBoxConsultaIdade = new System.Windows.Forms.TextBox();
            this.SuspendLayout();

            // labelCodigo
            this.labelCodigo.AutoSize = true;
            this.labelCodigo.Location = new System.Drawing.Point(12, 20);
            this.labelCodigo.Name = "labelCodigo";
            this.labelCodigo.Size = new System.Drawing.Size(46, 13);
            this.labelCodigo.Text = "Código:";

            // labelNome
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(12, 50);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(38, 13);
            this.labelNome.Text = "Nome:";

            // labelSexo
            this.labelSexo.AutoSize = true;
            this.labelSexo.Location = new System.Drawing.Point(12, 80);
            this.labelSexo.Name = "labelSexo";
            this.labelSexo.Size = new System.Drawing.Size(36, 13);
            this.labelSexo.Text = "Sexo:";

            // labelIdade
            this.labelIdade.AutoSize = true;
            this.labelIdade.Location = new System.Drawing.Point(12, 110);
            this.labelIdade.Name = "labelIdade";
            this.labelIdade.Size = new System.Drawing.Size(39, 13);
            this.labelIdade.Text = "Idade:";

            // textBoxCodigo
            this.textBoxCodigo.Location = new System.Drawing.Point(80, 17);
            this.textBoxCodigo.Name = "textBoxCodigo";
            this.textBoxCodigo.Size = new System.Drawing.Size(200, 20);
            this.textBoxCodigo.TabIndex = 0;

            // textBoxNome
            this.textBoxNome.Location = new System.Drawing.Point(80, 47);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(200, 20);
            this.textBoxNome.TabIndex = 1;

            // comboBoxSexo
            this.comboBoxSexo.Location = new System.Drawing.Point(80, 77);
            this.comboBoxSexo.Name = "comboBoxSexo";
            this.comboBoxSexo.Size = new System.Drawing.Size(80, 21);
            this.comboBoxSexo.TabIndex = 2;

            // maskedTextBoxIdade
            this.maskedTextBoxIdade.Location = new System.Drawing.Point(80, 107);
            this.maskedTextBoxIdade.Name = "maskedTextBoxIdade";
            this.maskedTextBoxIdade.Size = new System.Drawing.Size(80, 20);
            this.maskedTextBoxIdade.TabIndex = 3;

            // buttonCadastrar
            this.buttonCadastrar.Location = new System.Drawing.Point(80, 140);
            this.buttonCadastrar.Name = "buttonCadastrar";
            this.buttonCadastrar.Size = new System.Drawing.Size(100, 30);
            this.buttonCadastrar.Text = "Cadastrar";
            this.buttonCadastrar.UseVisualStyleBackColor = true;
            this.buttonCadastrar.Click += new System.EventHandler(this.buttonCadastrar_Click);

            // labelConsultaCodigo
            this.labelConsultaCodigo.AutoSize = true;
            this.labelConsultaCodigo.Location = new System.Drawing.Point(12, 200);
            this.labelConsultaCodigo.Name = "labelConsultaCodigo";
            this.labelConsultaCodigo.Size = new System.Drawing.Size(46, 13);
            this.labelConsultaCodigo.Text = "Código:";

            // textBoxConsultaCodigo
            this.textBoxConsultaCodigo.Location = new System.Drawing.Point(80, 197);
            this.textBoxConsultaCodigo.Name = "textBoxConsultaCodigo";
            this.textBoxConsultaCodigo.Size = new System.Drawing.Size(200, 20);
            this.textBoxConsultaCodigo.TabIndex = 4;

            // buttonConsultar
            this.buttonConsultar.Location = new System.Drawing.Point(80, 230);
            this.buttonConsultar.Name = "buttonConsultar";
            this.buttonConsultar.Size = new System.Drawing.Size(100, 30);
            this.buttonConsultar.Text = "Consultar";
            this.buttonConsultar.UseVisualStyleBackColor = true;
            this.buttonConsultar.Click += new System.EventHandler(this.buttonConsultar_Click);

            // labelConsultaNome
            this.labelConsultaNome.AutoSize = true;
            this.labelConsultaNome.Location = new System.Drawing.Point(12, 270);
            this.labelConsultaNome.Name = "labelConsultaNome";
            this.labelConsultaNome.Size = new System.Drawing.Size(38, 13);
            this.labelConsultaNome.Text = "Nome:";

            // labelConsultaSexo
            this.labelConsultaSexo.AutoSize = true;
            this.labelConsultaSexo.Location = new System.Drawing.Point(12, 300);
            this.labelConsultaSexo.Name = "labelConsultaSexo";
            this.labelConsultaSexo.Size = new System.Drawing.Size(36, 13);
            this.labelConsultaSexo.Text = "Sexo:";

            // labelConsultaIdade
            this.labelConsultaIdade.AutoSize = true;
            this.labelConsultaIdade.Location = new System.Drawing.Point(12, 330);
            this.labelConsultaIdade.Name = "labelConsultaIdade";
            this.labelConsultaIdade.Size = new System.Drawing.Size(39, 13);
            this.labelConsultaIdade.Text = "Idade:";

            // textBoxConsultaNome
            this.textBoxConsultaNome.Location = new System.Drawing.Point(80, 267);
            this.textBoxConsultaNome.Name = "textBoxConsultaNome";
            this.textBoxConsultaNome.ReadOnly = true;
            this.textBoxConsultaNome.Size = new System.Drawing.Size(200, 20);
            this.textBoxConsultaNome.TabIndex = 5;

            // textBoxConsultaSexo
            this.textBoxConsultaSexo.Location = new System.Drawing.Point(80, 297);
            this.textBoxConsultaSexo.Name = "textBoxConsultaSexo";
            this.textBoxConsultaSexo.ReadOnly = true;
            this.textBoxConsultaSexo.Size = new System.Drawing.Size(80, 20);
            this.textBoxConsultaSexo.TabIndex = 6;

            // textBoxConsultaIdade
            this.textBoxConsultaIdade.Location = new System.Drawing.Point(80, 327);
            this.textBoxConsultaIdade.Name = "textBoxConsultaIdade";
            this.textBoxConsultaIdade.ReadOnly = true;
            this.textBoxConsultaIdade.Size = new System.Drawing.Size(80, 20);
            this.textBoxConsultaIdade.TabIndex = 7;

            // Form1
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(300, 400);
            this.Controls.Add(this.labelCodigo);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.labelSexo);
            this.Controls.Add(this.labelIdade);
            this.Controls.Add(this.textBoxCodigo);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.comboBoxSexo);
            this.Controls.Add(this.maskedTextBoxIdade);
            this.Controls.Add(this.buttonCadastrar);
            this.Controls.Add(this.labelConsultaCodigo);
            this.Controls.Add(this.textBoxConsultaCodigo);
            this.Controls.Add(this.buttonConsultar);
            this.Controls.Add(this.labelConsultaNome);
            this.Controls.Add(this.labelConsultaSexo);
            this.Controls.Add(this.labelConsultaIdade);
            this.Controls.Add(this.textBoxConsultaNome);
            this.Controls.Add(this.textBoxConsultaSexo);
            this.Controls.Add(this.textBoxConsultaIdade);
            this.Name = "Form1";
            this.Text = "Cadastro de Pessoas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label labelCodigo;
        private System.Windows.Forms.Label labelNome;
        private System.Windows.Forms.Label labelSexo;
        private System.Windows.Forms.Label labelIdade;
        private System.Windows.Forms.TextBox textBoxCodigo;
        private System.Windows.Forms.TextBox textBoxNome;
        private System.Windows.Forms.ComboBox comboBoxSexo;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxIdade;
        private System.Windows.Forms.Button buttonCadastrar;
        private System.Windows.Forms.Label labelConsultaCodigo;
        private System.Windows.Forms.TextBox textBoxConsultaCodigo;
        private System.Windows.Forms.Button buttonConsultar;
        private System.Windows.Forms.Label labelConsultaNome;
        private System.Windows.Forms.Label labelConsultaSexo;
        private System.Windows.Forms.Label labelConsultaIdade;
        private System.Windows.Forms.TextBox textBoxConsultaNome;
        private System.Windows.Forms.TextBox textBoxConsultaSexo;
        private System.Windows.Forms.TextBox textBoxConsultaIdade;
    }
}