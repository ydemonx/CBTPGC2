﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace CadastroPessoas
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BDLivros.mdb";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new OleDbConnection(connectionString);

            comboBoxSexo.Items.AddRange(new object[] { "M", "F" });
            comboBoxSexo.DropDownStyle = ComboBoxStyle.DropDownList;

            maskedTextBoxIdade.Mask = "000";
            maskedTextBoxIdade.PromptChar = '_';
        }

        private void buttonCadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxCodigo.Text))
            {
                MessageBox.Show("O campo Código é obrigatório.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxNome.Text))
            {
                MessageBox.Show("O campo Nome é obrigatório.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (comboBoxSexo.SelectedItem == null)
            {
                MessageBox.Show("O campo Sexo é obrigatório. Selecione M ou F.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(maskedTextBoxIdade.Text, out int idade) || idade <= 0)
            {
                MessageBox.Show("O campo Idade deve ser um número inteiro maior que zero.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                connection.Open();
                string query = "INSERT INTO TabPessoa (codigo, nome, sexo, idade) VALUES (?, ?, ?, ?)";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("?", textBoxCodigo.Text);
                    command.Parameters.AddWithValue("?", textBoxNome.Text);
                    command.Parameters.AddWithValue("?", comboBoxSexo.SelectedItem.ToString());
                    command.Parameters.AddWithValue("?", maskedTextBoxIdade.Text);
                    command.ExecuteNonQuery();
                }
                MessageBox.Show("Pessoa cadastrada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao cadastrar: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void buttonConsultar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxConsultaCodigo.Text))
            {
                MessageBox.Show("Digite um código para consultar.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                connection.Open();
                string query = "SELECT * FROM TabPessoa WHERE codigo = ?";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("?", textBoxConsultaCodigo.Text);
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBoxConsultaNome.Text = reader["nome"].ToString();
                            textBoxConsultaSexo.Text = reader["sexo"].ToString();
                            textBoxConsultaIdade.Text = reader["idade"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Nenhuma pessoa encontrada com o código informado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearConsultaFields();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao consultar: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void ClearFields()
        {
            textBoxCodigo.Clear();
            textBoxNome.Clear();
            comboBoxSexo.SelectedIndex = -1;
            maskedTextBoxIdade.Clear();
        }

        private void ClearConsultaFields()
        {
            textBoxConsultaNome.Clear();
            textBoxConsultaSexo.Clear();
            textBoxConsultaIdade.Clear();
        }
    }
}