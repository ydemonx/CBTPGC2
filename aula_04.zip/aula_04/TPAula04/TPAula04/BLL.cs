﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPAula04
{
    class BLL
    {
        public static void conecta()
        {
            DAL.conecta();
        }

        public static void desconecta()
        {
            DAL.desconecta();
        }

        public static void validaCodigo(Produto umProduto, char op)
        {
            Erro.setErro(false);
            if (umProduto.getCodigo().Equals(""))
            {
                Erro.setMsg("O código é de preenchimento obrigatório!");
                return;
            }
            if (op == 'c')
                DAL.consultaUmProduto(umProduto);
            else
                DAL.excluiumProduto(umProduto);
        }

        public static void validaDados(Produto umProduto, char op)
        {

            if (umProduto == null)
            {
                Erro.setMsg("Ocorreu um erro grave: o produto recebido para validação é nulo.");
                Erro.setErro(true);
                return;
            }

            Erro.setErro(false);

            if (umProduto.getCodigo() == 0)
            {
                Erro.setMsg("O código é de preenchimento obrigatório!");
                return;
            }

            if (string.IsNullOrEmpty(umProduto.getDescricao()))
            {
                Erro.setMsg("A descrição é de preenchimento obrigatório!");
                return;
            }
            if (string.IsNullOrEmpty(umProduto.getFabricante()))
            {
                Erro.setMsg("A fabricante é de preenchimento obrigatório!");
                return;
            }

            if (umProduto.getQuantidade() == 0)
            {
                Erro.setMsg("A quantidade é de preenchimento obrigatório!");
                return;
            }
            if (umProduto.getValor() == 0)
            {
                Erro.setMsg("O valor é de preenchimento obrigatório!");
                return;
            }

            if (op == 'i')
                DAL.inseriUmProduto(umProduto);
            else
                DAL.atualizaUmProduto(umProduto);

        }
    }
}
