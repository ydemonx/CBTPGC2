﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace TPAula04
{
    class DAL
    {
        private static String strConexao = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=BDProduto.mdb";
        private static OleDbConnection conn = new OleDbConnection(strConexao);
        private static OleDbCommand strSQL;
        private static OleDbDataReader result;

        public static void conecta()
        {
            try
            {
                conn.Open();
            }
            catch (Exception)
            {
                Erro.setMsg("Problemas ao se conectar ao Banco de Dados");
            }

        }

        public static void desconecta()
        {
            conn.Close();
        }

        public static void inseriUmProduto(Produto umProduto)
        {
            String aux = "insert into TabProdutos(codigo,descricao,fabricante,quantidade,valor) values (@codigo,@descricao,@fabricante,@quantidade,@valor)";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umProduto.getCodigo();
            strSQL.Parameters.Add("@descricao", OleDbType.VarChar).Value = umProduto.getDescricao();
            strSQL.Parameters.Add("@fabricante", OleDbType.VarChar).Value = umProduto.getFabricante();
            strSQL.Parameters.Add("@quantidade", OleDbType.VarChar).Value = umProduto.getQuantidade();
            strSQL.Parameters.Add("@valor", OleDbType.VarChar).Value = umProduto.getValor();
            Erro.setErro(false);

            try
            {
                strSQL.ExecuteNonQuery();
            }
            catch (Exception)
            {
                Erro.setMsg("Chave Duplicada!");
            }
        }

        public static void excluiumProduto(Produto umProduto)
        {
            String aux = "delete from TabProdutos where codigo = @codigo";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umProduto.getCodigo();
            strSQL.ExecuteNonQuery();
        }
        public static void atualizaUmProduto(Produto umProduto)
        {
            String aux = "update TabProdutos set descricao=@descricao, fabricante=@fabricante, quantidade=@quantidade, valor=@valor where codigo =@codigo";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@descricao", OleDbType.VarChar).Value = umProduto.getDescricao();
            strSQL.Parameters.Add("@fabricante", OleDbType.VarChar).Value = umProduto.getFabricante();
            strSQL.Parameters.Add("@quantidade", OleDbType.VarChar).Value = umProduto.getQuantidade();
            strSQL.Parameters.Add("@valor", OleDbType.VarChar).Value = umProduto.getValor();
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umProduto.getCodigo();
            strSQL.ExecuteNonQuery();
        }

        public static void consultaUmProduto(Produto umProduto)
        {
            String aux = "select Descricao, Fabricante, Quantidade, Valor from TabProdutos where codigo = @codigo";

            OleDbCommand strSQL = null;
            OleDbDataReader result = null;

            try
            {
                strSQL = new OleDbCommand(aux, conn);

                strSQL.Parameters.Add("@codigo", OleDbType.Integer).Value = umProduto.getCodigo();

                result = strSQL.ExecuteReader();
                Erro.setErro(false);

                if (result.Read())
                {
                    if (result["Descricao"] != DBNull.Value) 
                        umProduto.setDescricao(result["Descricao"].ToString());

                    if (result["Fabricante"] != DBNull.Value)
                        umProduto.setFabricante(result["Fabricante"].ToString());

                    if (result["Quantidade"] != DBNull.Value)
                        umProduto.setQuantidade(Convert.ToInt32(result["Quantidade"]));

                    if (result["Valor"] != DBNull.Value)
                    {
                        umProduto.setValor(Convert.ToInt32(result["Valor"]));
                    }
                }
                else
                {
                    Erro.setErro(true); 
                    Erro.setMsg("Produto não cadastrado.");
                }
            }
            catch (Exception ex)
            {
                Erro.setErro(true);
                Erro.setMsg("Ocorreu um erro no banco de dados ao consultar o produto: " + ex.Message);
            }
            finally
            {
                if (result != null && !result.IsClosed)
                {
                    result.Close();
                }
            }
        }
    }
}
