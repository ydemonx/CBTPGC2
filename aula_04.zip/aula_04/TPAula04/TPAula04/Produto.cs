﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPAula04
{
    class Produto
    {
        private int codigo;
        private String descricao;
        private String fabricante;
        private int quantidade;
        private int valor;

        public void setCodigo(int _codigo) { codigo = _codigo; }
        public void setDescricao(String _descricao) { descricao = _descricao; }
        public void setFabricante(String _fabricante) { fabricante = _fabricante; }
        public void setQuantidade(int _quantidade) { quantidade = _quantidade; }
        public void setValor(int _valor) { valor = _valor; }

        public int getCodigo() { return codigo; }
        public String getDescricao() { return descricao; }
        public String getFabricante() { return fabricante; }
        public int getQuantidade() { return quantidade; }
        public int getValor() { return valor; }
    }
}
