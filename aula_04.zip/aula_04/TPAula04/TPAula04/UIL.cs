﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TPAula04
{
    public partial class UIL : Form
    {
        Produto umProduto = new Produto();

        public UIL()
        {
            InitializeComponent();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Produto produtoParaSalvar = new Produto();

            int codigo = 0;
            int.TryParse(msktxtCodigo.Text, out codigo);
            produtoParaSalvar.setCodigo(codigo);

            produtoParaSalvar.setDescricao(txtDescricao.Text);

            produtoParaSalvar.setFabricante(txtFabricante.Text);

            int quantidade = 0;
            int.TryParse(msktxtQuantidade.Text, out quantidade);
            produtoParaSalvar.setQuantidade(quantidade);

            int valorFinal = 0;
            string textoDoValor = msktxtValor.Text;

            string valorApenasNumeros = "";
            foreach (char caractere in textoDoValor)
            {
                if (char.IsDigit(caractere))
                {
                    valorApenasNumeros += caractere;
                }
            }

            if (!string.IsNullOrEmpty(valorApenasNumeros))
            {
                int.TryParse(valorApenasNumeros, out valorFinal);
            }
            produtoParaSalvar.setValor(valorFinal);

            BLL.validaDados(produtoParaSalvar, 'i'); 

            if (Erro.getErro())
            {
                MessageBox.Show(Erro.getMsg());
            }
            else
            {
                MessageBox.Show("Dados inseridos com sucesso!");
            }
        }

        private void UIL_Load(object sender, EventArgs e)
        {
            BLL.conecta();
            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            msktxtCodigo.Text = "";
            txtDescricao.Text = "";
            txtFabricante.Text = "";
            msktxtQuantidade.Text = "";
            msktxtValor.Text = "";
        }

        private void btnLer_Click(object sender, EventArgs e)
        {
            int codigoProduto; 
            bool sucesso = int.TryParse(msktxtCodigo.Text, out codigoProduto);

            if (sucesso)
            {
                umProduto.setCodigo(codigoProduto);

                BLL.validaCodigo(umProduto, 'c');

                if (Erro.getErro())
                {
                    MessageBox.Show(Erro.getMsg());
                }
                else
                {
                    msktxtCodigo.Text = umProduto.getCodigo().ToString();
                    txtDescricao.Text = umProduto.getDescricao();
                    txtFabricante.Text = umProduto.getFabricante();
                    msktxtQuantidade.Text = umProduto.getQuantidade().ToString();
                    msktxtValor.Text = umProduto.getValor().ToString();
                }
            }
            else
            {
                MessageBox.Show("Por favor, digite um código numérico válido para a consulta.");
            }
        }

        private void UIL_FormClosing(object sender, FormClosingEventArgs e)
        {
            BLL.desconecta();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int codigoProduto;
            bool sucesso = int.TryParse(msktxtCodigo.Text, out codigoProduto);

            if (sucesso)
            {
                umProduto.setCodigo(codigoProduto);

                BLL.validaCodigo(umProduto, 'e');

                if (Erro.getErro())
                {
                    MessageBox.Show(Erro.getMsg());
                }
                else
                {
                    MessageBox.Show("Produto Excluído!");
                }
            }
            else
            {
                MessageBox.Show("Por favor, digite um código numérico válido.");
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            msktxtCodigo.Text = umProduto.getCodigo().ToString();
            txtDescricao.Text = umProduto.getDescricao();
            txtFabricante.Text = umProduto.getFabricante();
            msktxtQuantidade.Text = umProduto.getQuantidade().ToString();
            msktxtValor.Text = umProduto.getValor().ToString();

            BLL.validaDados(umProduto, 'a');

            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            else
                MessageBox.Show("Dados alterados com sucesso!");
        }
    }
}
