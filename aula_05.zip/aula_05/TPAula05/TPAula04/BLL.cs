﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPAula04
{
    class BLL
    {
        public static void conecta()
        {
            DAL.conecta();
        }

        public static void desconecta()
        {
            DAL.desconecta();
        }

        public static void validaCodigo(Disciplina umaDisciplina, char op)
        {
            Erro.setErro(false);
            if (umaDisciplina.getCodigo().Equals(""))
            {
                Erro.setMsg("O código é de preenchimento obrigatório!");
                return;
            }
            if (op == 'c')
                DAL.consultaUmaDisciplina(umaDisciplina);
            else
                DAL.excluiUmaDisciplina(umaDisciplina);
        }

        public static void validaDados(Disciplina umaDisciplina, char op)
        {
            Erro.setErro(false);
            if (umaDisciplina.getCodigo().Equals(""))
            {
                Erro.setMsg("O código é de preenchimento obrigatório!");
                return;
            }
            if (umaDisciplina.getNome().Equals(""))
            {
                Erro.setMsg("O nome é de preenchimento obrigatório!");
                return;
            }
            if (umaDisciplina.getCarga().Equals(""))
            {
                Erro.setMsg("A carga horária é de preenchimento obrigatório!");
                return;
            }
            if (op == 'i')
                DAL.inserirUmaDisciplina(umaDisciplina);
            else
                DAL.atualizaUmaDisciplina(umaDisciplina);
        }
    }
}
