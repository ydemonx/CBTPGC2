﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace TPAula04
{
    class DAL
    {
        private static String strConexao = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=BDAcademico.mdb";
        private static OleDbConnection conn = new OleDbConnection(strConexao);
        private static OleDbCommand strSQL;
        private static OleDbDataReader result;

        public static void conecta()
        {
            try
            {
                conn.Open();
            }
            catch (Exception)
            {
                Erro.setMsg("Problemas ao se conectar ao Banco de Dados");
            }

        }

        public static void desconecta()
        {
            conn.Close();
        }
        
        public static void inserirUmaDisciplina(Disciplina umaDisciplina)
        {
            String aux = "insert into TabDisciplinas(codigo,nome,cargahoraria) values (@codigo,@nome,@carga)";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umaDisciplina.getCodigo();
            strSQL.Parameters.Add("@nome", OleDbType.VarChar).Value = umaDisciplina.getNome();
            strSQL.Parameters.Add("@carga", OleDbType.VarChar).Value = umaDisciplina.getCarga();
            Erro.setErro(false);

            try
            {
                strSQL.ExecuteNonQuery();
            }
            catch (Exception)
            {
                Erro.setMsg("Chave Duplicada!");
            }
        }

        public static void excluiUmaDisciplina(Disciplina umaDisciplina)
        {
            String aux = "delete from TabDisciplinas where codigo = @codigo";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umaDisciplina.getCodigo();
            strSQL.ExecuteNonQuery();
        }
        public static void atualizaUmaDisciplina(Disciplina umaDisciplina)
        {
            String aux = "update TabDisciplinas set cargahoraria=@carga, nome=@nome where codigo =@codigo";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@nome", OleDbType.VarChar).Value = umaDisciplina.getNome();
            strSQL.Parameters.Add("@carga", OleDbType.VarChar).Value = umaDisciplina.getCarga();
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umaDisciplina.getCodigo();
            strSQL.ExecuteNonQuery();
        }

        public static void consultaUmaDisciplina(Disciplina umaDisciplina)
        {
            String aux = "select * from TabDisciplinas where codigo = @codigo";

            strSQL = new OleDbCommand(aux, conn);
            strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umaDisciplina.getCodigo();
            result = strSQL.ExecuteReader();
            Erro.setErro(false);
            if (result.Read())
            {
                umaDisciplina.setNome(result.GetString(1));
                umaDisciplina.setCarga(result.GetInt32(2).ToString());
            }
            else
                Erro.setMsg("Disciplina não cadastrada.");
        }
    }
}
