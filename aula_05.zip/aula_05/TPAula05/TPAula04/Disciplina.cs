﻿using System;

namespace TPAula04
{
    public class Disciplina
    {
        private String codigo;
        private String nome;
        private String carga;

        public void setCodigo(String _codigo) { codigo = _codigo; }
        public void setNome(String _nome) { nome = _nome; }
        public void setCarga(String _carga) { carga = _carga; }
        public String getCodigo() { return codigo; }
        public String getNome() { return nome; }
        public String getCarga() { return carga; }
    }
}