﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TPAula04
{
    public partial class UIL : Form
    {

        Disciplina umaDisciplina = new Disciplina();

        public UIL()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            umaDisciplina.setCodigo(txtCodigo.Text);
            umaDisciplina.setNome(txtNome.Text);
            umaDisciplina.setCarga(txtCargaHoraria.Text);

            BLL.validaDados(umaDisciplina, 'i');

            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            else
                MessageBox.Show("Dados inseridos com sucesso!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtNome.Text = "";
            txtCargaHoraria.Text = "";
        }

        
        private void btnLer_Click(object sender, EventArgs e)
        {
            umaDisciplina.setCodigo(txtCodigo.Text);

            BLL.validaCodigo(umaDisciplina, 'c');

            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            else
            {
                txtCodigo.Text = (string)umaDisciplina.getCodigo();
                txtNome.Text = (string)umaDisciplina.getNome();
                txtCargaHoraria.Text = (string)umaDisciplina.getCarga();
            }
        }

        private void UIL_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            umaDisciplina.setCodigo(txtCodigo.Text);

            BLL.validaCodigo(umaDisciplina, 'e');

            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            else
                MessageBox.Show("Disciplina excluída!");
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            umaDisciplina.setCodigo(txtCodigo.Text);
            umaDisciplina.setNome(txtNome.Text);
            umaDisciplina.setCarga(txtCargaHoraria.Text);

            BLL.validaDados(umaDisciplina, 'a');

            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            else
                MessageBox.Show("Dados alterados com sucesso!");
        }

        private void UIL_Load_1(object sender, EventArgs e)
        {
            BLL.conecta();
            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
        }

        private void UIL_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            BLL.desconecta();
        }
    }
}
