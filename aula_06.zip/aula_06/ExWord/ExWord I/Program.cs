﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Word;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Application word = new Application();
            Document doc = word.Documents.Add();
            Selection texto = word.Selection;
 
            doc.Activate();
            texto.TypeText("Primeira Linha.\n");
            texto.TypeParagraph();
            texto.TypeText("Segunda Linha.\n");
            texto.TypeParagraph();
            texto.TypeText("Terceira Linha.\n");
            doc.SaveAs(@"D:\semestre_2\programacao_2\aula_06\ExWord\ExWord I\bin\Debug\matar\teste.doc");
            doc.SaveAs(@"D:\semestre_2\programacao_2\aula_06\ExWord\ExWord I\bin\Debug\matar\teste.docx");
            doc.SaveAs(@"D:\semestre_2\programacao_2\aula_06\ExWord\ExWord I\bin\Debug\matar\teste.pdf", WdSaveFormat.wdFormatPDF);

            word.Documents.Close();
            word.Quit();
        }
    }
}
