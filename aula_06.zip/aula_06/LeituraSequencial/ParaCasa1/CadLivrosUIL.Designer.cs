﻿namespace ParaCasa1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxLivros = new System.Windows.Forms.ListBox();
            this.btnListBox = new System.Windows.Forms.Button();
            this.btnListWord = new System.Windows.Forms.Button();
            this.btnListExcel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxLivros
            // 
            this.listBoxLivros.FormattingEnabled = true;
            this.listBoxLivros.Location = new System.Drawing.Point(12, 12);
            this.listBoxLivros.Name = "listBoxLivros";
            this.listBoxLivros.Size = new System.Drawing.Size(439, 173);
            this.listBoxLivros.TabIndex = 0;
            // 
            // btnListBox
            // 
            this.btnListBox.Location = new System.Drawing.Point(12, 201);
            this.btnListBox.Name = "btnListBox";
            this.btnListBox.Size = new System.Drawing.Size(146, 23);
            this.btnListBox.TabIndex = 1;
            this.btnListBox.Text = "Listar no ListBox";
            this.btnListBox.UseVisualStyleBackColor = true;
            this.btnListBox.Click += new System.EventHandler(this.btnListBox_Click);
            // 
            // btnListWord
            // 
            this.btnListWord.Location = new System.Drawing.Point(158, 201);
            this.btnListWord.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnListWord.Name = "btnListWord";
            this.btnListWord.Size = new System.Drawing.Size(146, 23);
            this.btnListWord.TabIndex = 2;
            this.btnListWord.Text = "Listar no Word";
            this.btnListWord.UseVisualStyleBackColor = true;
            this.btnListWord.Click += new System.EventHandler(this.btnListWord_Click);
            // 
            // btnListExcel
            // 
            this.btnListExcel.Location = new System.Drawing.Point(304, 201);
            this.btnListExcel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnListExcel.Name = "btnListExcel";
            this.btnListExcel.Size = new System.Drawing.Size(146, 23);
            this.btnListExcel.TabIndex = 3;
            this.btnListExcel.Text = "Listar no Excel";
            this.btnListExcel.UseVisualStyleBackColor = true;
            this.btnListExcel.Click += new System.EventHandler(this.btnListExcel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 234);
            this.Controls.Add(this.btnListExcel);
            this.Controls.Add(this.btnListWord);
            this.Controls.Add(this.btnListBox);
            this.Controls.Add(this.listBoxLivros);
            this.Name = "Form1";
            this.Text = "CADASTRO";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxLivros;
        private System.Windows.Forms.Button btnListBox;
        private System.Windows.Forms.Button btnListWord;
        private System.Windows.Forms.Button btnListExcel;
    }
}

