﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Reflection;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;


namespace ParaCasa1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private DataTable ObterDadosDosLivros()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("codLivro", typeof(int));
            dt.Columns.Add("tituloLivro", typeof(string));
            dt.Columns.Add("autorLivro", typeof(string));
            dt.Columns.Add("anoLivro", typeof(int));

            dt.Rows.Add(1, "O Senhor dos Anéis", "J.R.R. Tolkien", 1954);
            dt.Rows.Add(2, "Dom Casmurro", "Machado de Assis", 1899);
            dt.Rows.Add(3, "A Culpa é das Estrelas", "John Green", 2012);
            dt.Rows.Add(4, "1984", "George Orwell", 1949);

            return dt;
        }

        private void btnListBox_Click(object sender, EventArgs e)
        {
            listBoxLivros.Items.Clear();

            DataTable dt = ObterDadosDosLivros();

            foreach (DataRow row in dt.Rows)
            {
                string item = $"ID: {row["codLivro"]}, Título: {row["tituloLivro"]}, Autor: {row["autorLivro"]}";
                listBoxLivros.Items.Add(item);
            }

            MessageBox.Show("Livros listados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnListWord_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = ObterDadosDosLivros();

                Word.Application wordApp = new Word.Application();
                wordApp.Visible = true;
                Word.Document doc = wordApp.Documents.Add();

                Word.Paragraph title = doc.Content.Paragraphs.Add();
                title.Range.Text = "Listagem de Livros";
                title.Range.Font.Bold = 1;
                title.Range.Font.Size = 16;
                title.Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                title.Range.InsertParagraphAfter();

                foreach (DataRow row in dt.Rows)
                {
                    Word.Paragraph bookParagraph = doc.Content.Paragraphs.Add();
                    bookParagraph.Range.Text = $"Título: {row["tituloLivro"]}";
                    bookParagraph.Range.Font.Bold = 1;
                    bookParagraph.Range.InsertParagraphAfter();

                    Word.Paragraph authorParagraph = doc.Content.Paragraphs.Add();
                    authorParagraph.Range.Text = $"   Autor: {row["autorLivro"]}";
                    authorParagraph.Range.Font.Bold = 0;
                    authorParagraph.Range.InsertParagraphAfter();

                    Word.Paragraph yearParagraph = doc.Content.Paragraphs.Add();
                    yearParagraph.Range.Text = $"   Ano: {row["anoLivro"]}\n";
                    yearParagraph.Range.Font.Bold = 0;
                    yearParagraph.Range.InsertParagraphAfter();
                }

                string savePath = System.IO.Path.Combine(Application.StartupPath, "listagem.doc");

                doc.SaveAs2(savePath);

                MessageBox.Show($"Documento do Word gerado com sucesso em:\n{savePath}", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao gerar o documento do Word: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnListExcel_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = ObterDadosDosLivros();

                Excel.Application excel = new Excel.Application();
                excel.Visible = true;
                Excel.Workbook wb = excel.Workbooks.Add(Missing.Value);
                Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    ws.Cells[1, (i + 1)] = dt.Columns[i].ColumnName;
                    ((Excel.Range)ws.Cells[1, (i + 1)]).Font.Bold = true;
                }
                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        ws.Cells[(j + 2), (i + 1)] = dt.Rows[j][i];
                    }
                }
                ws.Columns.AutoFit();

                string savePath = System.IO.Path.Combine(Application.StartupPath, "listagem.xls");

                wb.SaveAs(savePath, Excel.XlFileFormat.xlWorkbookNormal, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Excel.XlSaveAsAccessMode.xlExclusive, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);

                MessageBox.Show($"Planilha do Excel gerada com sucesso em:\n{savePath}", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao gerar a planilha do Excel: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}


