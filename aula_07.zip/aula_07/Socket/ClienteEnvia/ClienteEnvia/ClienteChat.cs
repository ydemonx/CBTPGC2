﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace ClienteEnvia
{
    public partial class ClienteChat : Form
    {
        private TcpClient cliente;
        private StreamWriter escritor;
        private StreamReader leitor;

        public ClienteChat()
        {
            InitializeComponent();
        }

        

        private void ConectarAoServidor()
        {
            try
            {
                cliente = new TcpClient("127.0.0.1", 9060);
                NetworkStream stream = cliente.GetStream();
                escritor = new StreamWriter(stream) { AutoFlush = true };
                AtualizarHistorico("Conectado ao servidor!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível conectar ao servidor: " + ex.Message, "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Invoke((MethodInvoker)delegate { this.Close(); });
            }
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string mensagem = txtMensagem.Text;

            if (cliente != null && cliente.Connected && !string.IsNullOrEmpty(mensagem))
            {
                try
                {
                    escritor.WriteLine(mensagem);

                    AtualizarHistorico("Eu: " + mensagem);

                    txtMensagem.Clear();
                    txtMensagem.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao enviar mensagem: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (string.IsNullOrEmpty(mensagem))
            {
                MessageBox.Show("Por favor, digite uma mensagem.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("Não há conexão com o servidor.", "Erro de Conexão", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AtualizarHistorico(string texto)
        {
            if (listBoxHistorico.InvokeRequired)
            {
                listBoxHistorico.Invoke((MethodInvoker)delegate {
                    listBoxHistorico.Items.Add(texto);
                });
            }
            else
            {
                listBoxHistorico.Items.Add(texto);
            }
        }

        private void ClienteChat_Load(object sender, EventArgs e)
        {
            Task.Run(() => ConectarAoServidor());
        }

        private void ClienteChat_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (escritor != null) escritor.Close();
            if (cliente != null) cliente.Close();
        }
    }
}