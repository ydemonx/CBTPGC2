﻿namespace ServidorRecebe
{
    partial class ServidorChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxMensagens = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listBoxMensagens
            // 
            this.listBoxMensagens.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxMensagens.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxMensagens.FormattingEnabled = true;
            this.listBoxMensagens.ItemHeight = 20;
            this.listBoxMensagens.Location = new System.Drawing.Point(0, 0);
            this.listBoxMensagens.Name = "listBoxMensagens";
            this.listBoxMensagens.Size = new System.Drawing.Size(607, 279);
            this.listBoxMensagens.TabIndex = 0;
            // 
            // ServidorChat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 279);
            this.Controls.Add(this.listBoxMensagens);
            this.Name = "ServidorChat";
            this.Text = "Servidor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ServidorChat_FormClosing);
            this.Load += new System.EventHandler(this.ServidorChat_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxMensagens;
    }
}