﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServidorRecebe
{
    public partial class ServidorChat : Form
    {
        private TcpListener listener;
        private bool isRunning = true;


        public ServidorChat()
        {
            InitializeComponent();
        }

        private void ServidorChat_Load(object sender, EventArgs e)
        {
            Task.Run(() => IniciarServidor());
        }

        private void IniciarServidor()
        {
            try
            {
                listener = new TcpListener(IPAddress.Any, 9060);
                listener.Start();

                while (isRunning)
                {
                    AdicionarLog("Servidor iniciado. Aguardando conexão do cliente...");

                    TcpClient cliente = listener.AcceptTcpClient();
                    AdicionarLog("Cliente conectado!");

                    NetworkStream stream = cliente.GetStream();
                    StreamReader leitor = new StreamReader(stream);
                    string mensagem;

                    while ((mensagem = leitor.ReadLine()) != null)
                    {
                        AdicionarLog("Cliente: " + mensagem);
                    }

                    AdicionarLog("Cliente desconectado.");
                    leitor.Close();
                    cliente.Close();
                }
            }
            catch (SocketException ex)
            {
                if (isRunning)
                    MessageBox.Show("Erro de Socket: " + ex.Message, "Erro de Rede");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro: " + ex.Message, "Erro no Servidor");
            }
        }

        private void AdicionarLog(string log)
        {
            if (this.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate {
                    AdicionarLog(log);
                });
            }
            else
            {
                listBoxMensagens.Items.Add(log);
                listBoxMensagens.TopIndex = listBoxMensagens.Items.Count - 1;
                listBoxMensagens.Refresh();
            }
        }

        private void ServidorChat_FormClosing(object sender, FormClosingEventArgs e)
        {
            isRunning = false;
            if (listener != null)
            {
                listener.Stop();
            }
        }
    }
}
