﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClienteEnvia
{
    public partial class ClienteChat : Form
    {
        private TcpClient cliente;
        private StreamWriter escritor;
        private StreamReader leitor; 

        public ClienteChat()
        {
            InitializeComponent();
        }

        private void ClienteChat_Load(object sender, EventArgs e)
        {
            ConectarAoServidor();
        }

        private void ConectarAoServidor()
        {
            try
            {
                cliente = new TcpClient("127.0.0.1", 9060);
                NetworkStream stream = cliente.GetStream();
                escritor = new StreamWriter(stream) { AutoFlush = true };
                leitor = new StreamReader(stream);

                Task.Run(() => ReceberMensagens());

                AtualizarHistorico("Conectado ao servidor!");
            }
            catch (Exception)
            {
                AtualizarHistorico("Não foi possível conectar ao servidor.");
            }
        }

        private void ReceberMensagens()
        {
            try
            {
                string mensagem;
                while ((mensagem = leitor.ReadLine()) != null)
                {
                    AtualizarHistorico("Servidor: " + mensagem);
                }
            }
            catch
            {
                AtualizarHistorico("O servidor se desconectou.");
            }
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string mensagem = txtMensagem.Text;
            if (cliente != null && cliente.Connected && !string.IsNullOrEmpty(mensagem))
            {
                escritor.WriteLine(mensagem);
                AtualizarHistorico("Cliente: " + mensagem);
                txtMensagem.Clear();
            }
            else
            {
                AtualizarHistorico("Não conectado. Não é possível enviar a mensagem.");
            }
        }

        private void AtualizarHistorico(string texto)
        {
            if (listBoxHistorico.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate { AtualizarHistorico(texto); });
            }
            else
            {
                listBoxHistorico.Items.Add(texto);
                listBoxHistorico.TopIndex = listBoxHistorico.Items.Count - 1;
            }
        }

        private void ClienteChat_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (escritor != null) escritor.Close();
            if (leitor != null) leitor.Close();
            if (cliente != null) cliente.Close();
        }
    }
}
