﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServidorRecebe
{
    public partial class ServidorChat : Form
    {
        private TcpListener listener;
        private TcpClient cliente;
        private StreamWriter escritor;
        private bool isRunning = false;

        public ServidorChat()
        {
            InitializeComponent();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            Task.Run(() => IniciarServidor());

            btnIniciar.Enabled = false;
            btnParar.Enabled = true;
        }
        private void IniciarServidor()
        {
            try
            {
                isRunning = true;
                listener = new TcpListener(IPAddress.Any, 9060);
                listener.Start();

                AdicionarLog("Servidor iniciado. Aguardando conexão...");

                cliente = listener.AcceptTcpClient();
                isRunning = true; 

                escritor = new StreamWriter(cliente.GetStream()) { AutoFlush = true };
                StreamReader leitor = new StreamReader(cliente.GetStream());

                AdicionarLog("Cliente conectado! Agora você pode enviar e receber mensagens.");
                HabilitarControlesDeEnvio(true);

                string mensagem;
                while (isRunning && (mensagem = leitor.ReadLine()) != null)
                {
                    AdicionarLog("Cliente: " + mensagem);
                }
            }
            catch (SocketException)
            {
                AdicionarLog("Servidor parado.");
            }
            catch (Exception ex)
            {
                AdicionarLog("Erro: " + ex.Message);
            }
            finally
            {
                PararServidor();
            }
        }

        private void PararServidor()
        {
            isRunning = false;

            if (escritor != null) escritor.Close();
            if (cliente != null) cliente.Close();
            if (listener != null) listener.Stop();

            HabilitarControlesDeEnvio(false);
            if (btnIniciar.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate {
                    btnIniciar.Enabled = true;
                    btnParar.Enabled = false;
                });
            }
            else
            {
                btnIniciar.Enabled = true;
                btnParar.Enabled = false;
            }
        }

        private void HabilitarControlesDeEnvio(bool habilitar)
        {
            if (txtMensagem.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate {
                    txtMensagem.Enabled = habilitar;
                    btnEnviar.Enabled = habilitar;
                });
            }
            else
            {
                txtMensagem.Enabled = habilitar;
                btnEnviar.Enabled = habilitar;
            }
        }

        private void AdicionarLog(string log)
        {
            if (this.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate {AdicionarLog(log);});
            }
            else
            {
                listBoxMensagens.Items.Add(log);
                listBoxMensagens.TopIndex = listBoxMensagens.Items.Count - 1;
            }
        }

        private void ServidorChat_FormClosing(object sender, FormClosingEventArgs e)
        {
            PararServidor();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string mensagem = txtMensagem.Text;
            if (escritor != null && !string.IsNullOrEmpty(mensagem))
            {
                escritor.WriteLine(mensagem);
                AdicionarLog("Servidor: " + mensagem);
                txtMensagem.Clear();
            }
        }

        private void btnParar_Click(object sender, EventArgs e)
        {
            PararServidor();
        }
    }
}
