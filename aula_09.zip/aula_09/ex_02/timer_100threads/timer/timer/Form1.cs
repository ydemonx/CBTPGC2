﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContadorDePrimosWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnIniciar_Click(object sender, EventArgs e)
        {
            btnIniciar.Enabled = false;
            lblStatus.Text = "Calculando... Por favor, aguarde.";
            lblResultado.Text = "Primos encontrados: ...";
            lblTempo.Text = "Tempo de execução: ...";
            Application.DoEvents(); 

            const int LimiteMaximo = 300000;
            const int numeroDeThreads = 100;

            Stopwatch stopwatch = Stopwatch.StartNew();

            long totalDePrimos = await Task.Run(() =>
            {
                List<Thread> threads = new List<Thread>();

                int[] contagemPorThread = new int[numeroDeThreads];

                int tamanhoDoIntervalo = LimiteMaximo / numeroDeThreads;

                for (int i = 0; i < numeroDeThreads; i++)
                {
                    int indiceThread = i;

                    int inicio = indiceThread * tamanhoDoIntervalo + 1;
                    int fim = (indiceThread + 1) * tamanhoDoIntervalo;

                    if (indiceThread == numeroDeThreads - 1)
                    {
                        fim = LimiteMaximo;
                    }

                    Thread t = new Thread(() =>
                    {
                        contagemPorThread[indiceThread] = ContarPrimosNoIntervalo(inicio, fim);
                    });
                    threads.Add(t);
                    t.Start();
                }

                foreach (Thread t in threads)
                {
                    t.Join();
                }

                return (long)contagemPorThread.Sum();
            });

            stopwatch.Stop();

            lblStatus.Text = "Cálculo Concluído!";
            lblResultado.Text = $"Primos encontrados: {totalDePrimos}";
            lblTempo.Text = $"Tempo de execução: {stopwatch.Elapsed.TotalSeconds:F3}s";
            btnIniciar.Enabled = true;
        }

        public int ContarPrimosNoIntervalo(int inicio, int fim)
        {
            int contagem = 0;
            for (int numero = inicio; numero <= fim; numero++)
            {
                if (EhPrimo(numero))
                {
                    contagem++;
                }
            }
            return contagem;
        }

        public bool EhPrimo(int numero)
        {
            if (numero <= 1) return false;
            if (numero == 2) return true;
            if (numero % 2 == 0) return false;

            var limite = (int)Math.Floor(Math.Sqrt(numero));
            for (int i = 3; i <= limite; i += 2)
            {
                if (numero % i == 0) return false;
            }
            return true;
        }
    }
}