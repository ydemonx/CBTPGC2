﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;

public class Program
{
    public static void Main(string[] args)
    {
        const int LimiteMaximo = 300000;

        int numeroDeThreads = Environment.ProcessorCount;

        Console.WriteLine($"Iniciando contagem de primos até {LimiteMaximo} usando {numeroDeThreads} threads...");
        Console.WriteLine("-----------------------------------------------------");

        Stopwatch stopwatch = new Stopwatch();
        stopwatch.Start();

        List<Thread> threads = new List<Thread>();

        int[] contagemPorThread = new int[numeroDeThreads];

        int tamanhoDoIntervalo = LimiteMaximo / numeroDeThreads;

        for (int i = 0; i < numeroDeThreads; i++)
        {
            int indiceThread = i;

            int inicio = indiceThread * tamanhoDoIntervalo + 1;
            int fim = (indiceThread + 1) * tamanhoDoIntervalo;

            if (indiceThread == numeroDeThreads - 1)
            {
                fim = LimiteMaximo;
            }

            Thread t = new Thread(() =>
            {
                contagemPorThread[indiceThread] = ContarPrimosNoIntervalo(inicio, fim);
            });

            threads.Add(t); 
            t.Start();    
        }

        foreach (Thread t in threads)
        {
            t.Join();
        }

        stopwatch.Stop();

        long totalDePrimos = contagemPorThread.Sum();

        Console.WriteLine($"\nOperação concluída!");
        Console.WriteLine($"Total de números primos encontrados entre 1 e {LimiteMaximo}: {totalDePrimos}");
        Console.WriteLine($"Tempo total de execução: {stopwatch.Elapsed.TotalSeconds:F3} segundos.");
    }

    
    public static int ContarPrimosNoIntervalo(int inicio, int fim)
    {
        int contagem = 0;
        for (int numero = inicio; numero <= fim; numero++)
        {
            if (EhPrimo(numero))
            {
                contagem++;
            }
        }
        return contagem;
    }

    
    public static bool EhPrimo(int numero)
    {
        if (numero <= 1) return false;
        if (numero == 2) return true;
        if (numero % 2 == 0) return false;

        var limite = (int)Math.Floor(Math.Sqrt(numero));
        for (int i = 3; i <= limite; i += 2)
        {
            if (numero % i == 0)
            {
                return false;
            }
        }

        return true;
    }
}